package com.example.floatingball;

import static android.view.View.TRANSLATION_X;
import static android.view.View.TRANSLATION_Y;
import static java.security.AccessController.getContext;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class MainActivity extends AppCompatActivity {
    //窗口的布局参数
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //动态请求权限
        if (checkOverPermission()) {
            startFloatingBallService();
        }
        View img = findViewById(R.id.test_img);
    }

    private boolean checkOverPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            //Build.VERSION.SDK_INT 表示当前系统的版本号
            //Build.VERSION_CODES.M 表示当前系统的版本号是6.0
            //!Settings.canDrawOverlays(this) 表示当前应用没有悬浮窗权限
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package" + getPackageName()));//参数的含义
            startActivityForResult(intent, 100);// 如果没有设置过悬浮窗权限，则跳转到设置页面
            return false;
        } else {
            return true;
        }


    }

    //从设置页面返回后会调用onActivityResult()方法
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) {
            if (checkOverPermission()) {
                startFloatingBallService();
            }
        }
    }

    private void startFloatingBallService() {
        Intent serviceIntent = new Intent(this, FloatingBallService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);// 3. 为什么要用startForegroundService()？
        } else {
            startService(serviceIntent);// 2. 为什么要用startService()？他们的区别
        }
    }

    //解决内存泄漏的问题
//    @Override
//    protected void onDestroy() {
//        if (mFloatingBall != null && mWindowManager != null) {
//            mWindowManager.removeView(mFloatingBall);
//        }
//        super.onDestroy();
//    }
}